import sys
from cx_Freeze import setup, Executable

options = {
    'build_exe': {
        'compressed': True,
        'create_shared_zip': True,
    }
}

executables = [
    Executable('JasonNumberCombinations.py'),
]

setup(name='Jason Number Combinations',
      version='0.1',
      description='Custom Python program for use in Jason EE',
      options=options,
      executables=executables
      )
