print("Enter list of numbers one by one, signify the end of list by typing 'END'")

numIN=""
numLIST=[]
combiLIST=[]
numSTORE=[]
numFINAL=0

while(True):
    numIN=input()
    if numIN=="END":
        break
    if (numIN.isdigit()!=True):
        print("Not a numerical input, rejected")
        continue
    else:
        numLIST.append(int(numIN))

if numLIST==[]:
    print("List is empty")
else:
    print("Numbers Listed:")
    print(numLIST)
    n=len(numLIST)-1
    r=0
    for i in numLIST:
        for j in range(n,r,-1):
            k=numLIST[j]
            combiLIST.append(str(i)+"*"+str(k))
            numSTORE.append(int(i*k))
        r+=1
    print("List of combinations:")
    print(combiLIST)
    print("Results of combinations:")
    print(numSTORE)
    print("Finding total...")
    for i in numSTORE:
        numFINAL+=i
    print("Total is: "+str(numFINAL))

with open("output.txt","a") as text_file:
    print("---------------", file=text_file)
    print("Numbers Listed:", file=text_file)
    print(combiLIST, file=text_file)
    print("Results of combinations:", file=text_file)
    print(numSTORE, file=text_file)
    print("Finding total...", file=text_file)
    print("Total is: "+str(numFINAL), file=text_file)
    print("---------------", file=text_file)
    
print("Data saved to output.txt, press enter to exit")
input()

           
        
