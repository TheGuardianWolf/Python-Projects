import os
import glob
for file in glob.glob("*.bin"):
    flash=file.replace(".bin",".swf")
    print("Processing and converting "+file+" to "+flash)
    os.system("extractaflash.exe "+file+" "+flash)
