import sys
from cx_Freeze import setup, Executable

options = {
    'build_exe': {
        'compressed': True,
        'includes': [
            'os',
        ],
        'include_files': [
            'extractaflash.exe',
        ],
        'create_shared_zip': True,
    }
}

executables = [
    Executable('ExtractFlashAutomate.py'),
]

setup(name='ExtractFlashAutomate',
      version='0.1',
      description='A program that will extract .swf files from powerpoint activex bin files',
      options=options,
      executables=executables
      )
